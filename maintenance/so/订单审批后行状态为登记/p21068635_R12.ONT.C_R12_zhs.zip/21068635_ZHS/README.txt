
==============================================================================
This patch delivers the bulk workflow feature
==============================================================================

Update   - 21068635
Product  - Oracle Order Management
Release  - R12
Language - Simplified Chinese
Built    - AUG-19-2015 18:15:31

==============================================================================
NLS Notes
==============================================================================
This may be a subset of the original base American English update because
it contains only the translatable files referenced by update 21068635
and its prerequisites. Since this update contains only the files that are
currently translated to Simplified Chinese, it's contents may vary compared to
another language.  You should install the American English version of this
update before applying this translation.

SPECIAL INSTRUCTIONS
This update contains the following unified driver file to be applied
with AutoPatch.
    u21068635.drv

******************************************************************************
The following text is from the base US update
******************************************************************************
Instructions For Applying This Patch
==============================================================================
Execute the following command to generate your instance specific installation
instructions

1. Source the Applications environment file
2. Run the Patch Application Assistant by entering &quot;admsi.pl&quot;.

The generic instructions for this patch are:

Post-install Tasks
==============================================================================
For 12.0.X / 12.1.X patches, you must complete the tasks in this
section before starting up Application tier services.
For 12.2.X patches, you may complete the tasks in this section at
any time after the update, without taking any services or users offline.



1. Restart Mobile Server [required]
This patch application needs the Mobile server to be restarted. Once the patch is applied successfully please restart the Mobile Server.

==============================================================================
Description
==============================================================================

This patch delivers the bulk workflow enhancement with all the latest bug fixes.

==============================================================================
Bugs Fixed
==============================================================================
The following bugs are fixed by this patch:

13801678 - ENTERING OF SERVICE REFERENCE ORDER NUMBER ON EXTENDED WARRANTY IS EXTREMELY SLO
14840826 - RCA FOR ITS ERROR ON SPLIT MODELS: 'ERROR MSG: SPLIT QUANTITIES MUST SUM UP TO O
17533452 - OE_INBOUND_INT IS INVALID
18229932 - ORDER ORGANIZER ERROR 'INVALID ARGUMENT TO OE_FIND.NO_EXPIRATION_DATE: EVENT='WH
18263807 - PERFORMANCE ISSUE OF ORDER IMPORT PROGRAM
18611800 - OEXOEORD -- WHEN TRYING TO BOOK SALES ORDER --  CANNOT GET VALID NAME FOR - EQUI
18633333 - GLOBALIZATION FLEXFIELD DOESN'T DEFAULT VALUES FOR REFERENCED RMA LINE (BRAZIL L
19364414 - LINE CANNOT BE ADDED TO SHIP SET 1 BECAUSE SHIPPING METHOD DOES NOT MATCH
19492871 - WF NOT ATTACHED/CREATED FOR ORDER LINES RANDOMLY
20458218 - USER-DEFINED EXCEPTION IN PACKAGE OE_ORDER_WF_UTIL PROCEDURE START_ALL_FLOWS
21068635 - WORKFLOW FOR THE LINE IS NOT CREATED WHEN USING PROCESS ORDER API VIA WORKFLOW .
21181025 - SALES ORDER HEADER CLOSED  WITH  OPEN LINE
2995513 - WANT TO MASS CHANGE OVERRIDE ATP
3638503 - RMAS NEED TO EXPLODE CONFIGURATIONS DURING ORDER ENTRY
6152570 - SHIP/ARRIVAL SETS SHOULD NOT BE ALLOWED  ON BILL-ONLY LINE TYPES


